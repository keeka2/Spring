package spring.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		//  로그인 체크
		HttpSession session = request.getSession(true);
		
		// 로그인 시 저장했던 객체를 얻어낸다.
		Object obj = session.getAttribute("mvo"); //obj가 있으면 true를 반환한다.
		
		if(obj == null) {
			response.sendRedirect("/login");//로그인 화면으로 이동
			return false;
		}
		
		
		return true;
	}

	
}
